#include "MultiplayCentrifugeLog.h"

DEFINE_LOG_CATEGORY(LogCentrifuge)