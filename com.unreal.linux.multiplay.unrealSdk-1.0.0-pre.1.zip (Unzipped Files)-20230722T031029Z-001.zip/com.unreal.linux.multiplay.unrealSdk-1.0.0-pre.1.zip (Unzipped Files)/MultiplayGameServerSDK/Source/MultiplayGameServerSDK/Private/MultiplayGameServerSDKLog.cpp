#include "MultiplayGameServerSDKLog.h"

DEFINE_LOG_CATEGORY(LogMultiplayGameServerSDK)
